-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Hoszt: 127.0.0.1:3306
-- Létrehozás ideje: 2017. Okt 09. 11:13
-- Szerver verzió: 5.7.17-11-57
-- PHP verzió: 5.6.30-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Adatbázis: `sas-uat_bank360_hu_db`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes`
--

CREATE TABLE IF NOT EXISTS `attributes` (
  `attribute_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes_custom_labels`
--

CREATE TABLE IF NOT EXISTS `attributes_custom_labels` (
  `attribute_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `label` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes_default_labels`
--

CREATE TABLE IF NOT EXISTS `attributes_default_labels` (
  `attribute_id` int(11) NOT NULL,
  `label` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `banks`
--

CREATE TABLE IF NOT EXISTS `banks` (
`id` smallint(5) unsigned NOT NULL,
  `title` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `home_savings` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `banks`
--

INSERT INTO `banks` (`id`, `title`, `active`, `home_savings`) VALUES
(1, 'Aegon Lakástakarék', 1, 1),
(2, 'Budapest Bank', 1, 0),
(3, 'Cetelem', 1, 0),
(4, 'CIB Bank', 1, 0),
(5, 'Cofidis', 1, 0),
(6, 'ERSTE Bank', 1, 0),
(7, 'ERSTE Lakástakarék', 1, 1),
(8, 'FHB Bank', 1, 0),
(9, 'Fundamenta', 1, 1),
(10, 'KH Bank', 1, 0),
(11, 'MKB Bank', 1, 0),
(12, 'OTP Bank', 1, 0),
(13, 'OTP Lakástakarék', 1, 1),
(14, 'Provident', 1, 0),
(15, 'Raiffeisen Bank', 1, 0),
(16, 'Sberbank', 1, 0),
(17, 'Takarék Bank', 1, 0),
(18, 'UniCredit Bank', 1, 0),
(19, 'Oney', 1, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_beneficiary`
--

CREATE TABLE IF NOT EXISTS `cases_beneficiary` (
`id` int(11) unsigned NOT NULL,
  `case_id` int(11) unsigned DEFAULT NULL,
  `van_kedvezmenyezett` tinyint(1) unsigned DEFAULT NULL,
  `nev` varchar(255) DEFAULT NULL,
  `szuletesi_nev` varchar(255) DEFAULT NULL,
  `anyja_szuletesi_neve` varchar(255) DEFAULT NULL,
  `szuletesi_hely` varchar(255) DEFAULT NULL,
  `szuletesi_ido` date DEFAULT NULL,
  `adoazonosito_jel` varchar(10) DEFAULT NULL,
  `allampolgarsag` varchar(255) DEFAULT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim` varchar(255) DEFAULT NULL,
  `telefonszam` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_beneficiary`
--

INSERT INTO `cases_beneficiary` (`id`, `case_id`, `van_kedvezmenyezett`, `nev`, `szuletesi_nev`, `anyja_szuletesi_neve`, `szuletesi_hely`, `szuletesi_ido`, `adoazonosito_jel`, `allampolgarsag`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim`, `telefonszam`) VALUES
(1, 1, 1, 'Kedv Név', 'Kedv Név', 'An', 'Otthon', '1961-09-23', '25415552', 'magyar', 1254, 'Budafok', 'Levél u. 54.', 'Lev cím', '6254154545'),
(2, 2, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 4, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_client_data`
--

CREATE TABLE IF NOT EXISTS `cases_client_data` (
`id` int(11) unsigned NOT NULL,
  `case_id` int(11) unsigned DEFAULT NULL,
  `ugyfel_forras` varchar(5) DEFAULT NULL,
  `ugyfel_tipusa` char(2) DEFAULT NULL,
  `nev` varchar(255) DEFAULT NULL,
  `ceg_kepviselojenek_neve` varchar(255) DEFAULT NULL,
  `szuletesi_nev` varchar(255) DEFAULT NULL,
  `anyja_szuletesi_neve` varchar(255) DEFAULT NULL,
  `szuletesi_hely` varchar(255) DEFAULT NULL,
  `szuletesi_ido` date DEFAULT NULL,
  `adoszam` varchar(10) DEFAULT NULL,
  `azonosito_okmany_tipusa` char(2) DEFAULT NULL,
  `azonosito_okmany_szama` varchar(255) DEFAULT NULL,
  `lakcimkartya_szama` varchar(30) DEFAULT NULL,
  `allampolgarsag` varchar(255) DEFAULT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim` varchar(255) DEFAULT NULL,
  `telefonszam` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `epulet_cime` varchar(255) DEFAULT NULL,
  `lakasok_szama` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_client_data`
--

INSERT INTO `cases_client_data` (`id`, `case_id`, `ugyfel_forras`, `ugyfel_tipusa`, `nev`, `ceg_kepviselojenek_neve`, `szuletesi_nev`, `anyja_szuletesi_neve`, `szuletesi_hely`, `szuletesi_ido`, `adoszam`, `azonosito_okmany_tipusa`, `azonosito_okmany_szama`, `lakcimkartya_szama`, `allampolgarsag`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim`, `telefonszam`, `email`, `epulet_cime`, `lakasok_szama`) VALUES
(1, 1, 'sajat', 'TE', 'Első Ügyfél', 'Képviselő', 'Első Ügyfél', 'Anya név', 'Budapest', '1984-09-05', '12541321', 'VE', '3543435', NULL, 'magyar', 2222, 'Budapest', 'Alma u. 15.', '1001 Budapest, Kolos u. 11.', '354343543', 'elso.ugyfel@hotmail.com', 'Épület cím', 1),
(2, 2, 'B360', 'TE', 'Béla', 'pali', 'Béla', 'Marika', 'Kórház', '2017-09-05', '99999999', 'SI', 'asdfadf', NULL, 'magyar', 1095, 'Budapest', 'Utca 52', '1095 Bp Utca 52', '123123123', 'asdf@asdf.hu', 'címe', 0),
(3, 3, 'sajat', 'TE', 'Kis István', 'nincs', 'Kis István', 'Nagy Mária', 'Busapet', '2017-09-19', '26130248-2', 'SI', '5555555555AB', NULL, 'magyar', 1111, 'Budapest', 'Utca 45', 'Fő utca 1.', '+3623123456', 'email@gmail.com', '1', 1),
(4, 4, 'sajat', 'LT', 'Varga Júlia', 'Varga Júlia', 'Szabó Júlia', 'Müller Piroska', 'Vác', '2017-09-06', '87654321', 'SI', '987654KW', NULL, 'magyar', 1111, 'Budapest', 'Üllői út 2.', 'ua.', '+36301234567', 'email@cim.hu', '.', 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_common`
--

CREATE TABLE IF NOT EXISTS `cases_common` (
`id` int(11) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `bank_id` smallint(5) unsigned DEFAULT NULL,
  `product_category` char(2) DEFAULT NULL,
  `penztar` varchar(255) DEFAULT NULL,
  `szerzodes_szam` varchar(255) DEFAULT NULL,
  `szerzodeses_osszeg_emeles` tinyint(1) unsigned DEFAULT NULL,
  `ugyfelelegedettsegi_lap_sorszama` varchar(255) DEFAULT NULL,
  `ugyfelelegedettsegi_lap_beerkezese` date DEFAULT NULL,
  `igenyfelmero_adatlap_sorszama` varchar(255) DEFAULT NULL,
  `igenyfelmero_adatlap_beerkezese` date DEFAULT NULL,
  `szerzodeskotes_datuma` date DEFAULT NULL,
  `varhato_indulas_datuma` date DEFAULT NULL,
  `befizetes_allapota` varchar(255) DEFAULT NULL,
  `termekcsalad` varchar(255) DEFAULT NULL,
  `futamido_ev` tinyint(2) unsigned DEFAULT NULL,
  `futamido_ho` tinyint(3) unsigned DEFAULT NULL,
  `befizetes_modja` varchar(255) DEFAULT NULL,
  `szamlanyitasi_dij` int(11) unsigned DEFAULT NULL,
  `szamlanyitasi_dij_kedvezmeny` varchar(255) DEFAULT NULL,
  `havi_befizetes` int(11) unsigned DEFAULT NULL,
  `szamlavezetesi_dij` varchar(255) DEFAULT NULL,
  `ltp_szerzodes_osszege` varchar(255) DEFAULT NULL,
  `megjegyzes` text CHARACTER SET utf8 COLLATE utf8_hungarian_ci
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_common`
--

INSERT INTO `cases_common` (`id`, `user_id`, `bank_id`, `product_category`, `penztar`, `szerzodes_szam`, `szerzodeses_osszeg_emeles`, `ugyfelelegedettsegi_lap_sorszama`, `ugyfelelegedettsegi_lap_beerkezese`, `igenyfelmero_adatlap_sorszama`, `igenyfelmero_adatlap_beerkezese`, `szerzodeskotes_datuma`, `varhato_indulas_datuma`, `befizetes_allapota`, `termekcsalad`, `futamido_ev`, `futamido_ho`, `befizetes_modja`, `szamlanyitasi_dij`, `szamlanyitasi_dij_kedvezmeny`, `havi_befizetes`, `szamlavezetesi_dij`, `ltp_szerzodes_osszege`, `megjegyzes`) VALUES
(1, 102, 1, 'HS', NULL, '125484552', 0, '44415', '2017-09-05', '646464', '2017-09-12', '2017-09-20', '2017-09-12', 'FV', 'Aegon Otthon 5 LSZB10', 5, 60, 'CS', 0, 'EHB', 545412, 'Aegon Otthon 5 LSZB09', '1925000', 'dfz dtzik'),
(2, 1, 1, 'HS', NULL, '123566', 0, '987654321', '2017-09-06', '654321', '2017-09-07', '2017-09-14', '2017-09-06', 'FV', 'Aegon Otthon 5 LSZB05', 5, 60, 'CS', 0, 'EHB', 5000, '150', '1050000', ''),
(3, 148, 13, 'HS', NULL, '66666666', 0, '555555', '2017-09-08', '444444', '2017-09-06', '2017-09-07', '2017-09-22', 'FV', 'Start 5 U', 5, 58, 'UT', 27000, 'EHB', 200000, '150', '2700000', 'megjegyzem, hogy megjegyzem'),
(4, 142, 1, 'HS', NULL, '77777777', 0, '12', '2017-09-05', '12', '2017-09-11', '2017-09-04', '2017-09-11', 'NI', 'Aegon Otthon 5 LSZB15', 5, 60, 'CS', 0, '0.5', 15000, '123', '2800000', 'Megjegyzés szöveg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
`id` int(11) NOT NULL,
  `company_name` text NOT NULL,
  `company_description` text,
  `default_language` char(2) NOT NULL,
  `company_logo` text,
  `tax_no` varchar(13) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `fundation_date` date DEFAULT NULL,
  `reg_office_postcode` smallint(5) unsigned DEFAULT NULL,
  `reg_office_town` varchar(50) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `reg_office_street` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_birth_date` date DEFAULT NULL,
  `representative_id_card_no` varchar(8) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `teaor` smallint(5) unsigned DEFAULT NULL,
  `bank_account_no` varchar(26) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `reg_no` varchar(12) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `company_description`, `default_language`, `company_logo`, `tax_no`, `fundation_date`, `reg_office_postcode`, `reg_office_town`, `reg_office_street`, `representative_name`, `representative_birth_date`, `representative_id_card_no`, `representative_address`, `teaor`, `bank_account_no`, `reg_no`, `phone`, `email`) VALUES
(6, 'Norti Hungary Kft.', NULL, 'hu', '', '23977750-2-41', '2012-06-05', 2083, 'Budapest', 'Váci út 170/c', 'Hack György Tamás', '1968-09-12', '396187AE', '2083 Solymár, Erdő u 35.', 6619, '10810001-00000006-33480006', '00000000', '+36301111111', 'hack@bank360.hu'),
(7, 'Financial Mentor Kft.', NULL, 'hu', '', '26127435-2-13', '2017-09-11', 2724, 'Újlengyel', 'Petőfi S. u. 48', 'Fejes Barbara Kitti', '1977-07-05', '660715RA', '1074 Bp, Alsóerdősor utca 32 2/22', 65535, '10400205-50526870-77551006', '13-09-189162', '000000', 'financialmentorkft@gmail.com'),
(8, 'PET SYLVER KFT', NULL, 'hu', '', '23180134-1-41', '2013-02-11', 1036, 'Budapest', 'Kolosy tér 5-6. fsz 14', 'Pozsonyi Péter', '1971-08-14', '122680MA', '1036 Bp, Kolosy tér 5-6 fszt 14.', 65535, '12010374-01575953-00100002', '01-09-956752', '111111', 'aaaa@aaaa.hu'),
(9, 'MC-Spirit Kft', NULL, 'hu', '', '26130248-2-42', '2017-09-13', 1173, 'Budapest', 'Vízhordó utca 52.', 'Nemes Judit', '1946-04-07', '611728TA', '2040 Budaörs Hegyalja utca 25.', 65535, '00000000-00000000', '01-09-303498', '111111', 'mcspiritkft@gmail.com'),
(10, 'Zentai-Csiszár Éva Ibolya EV', NULL, 'hu', '', '68173797-1-33', '2017-12-31', 2209, 'Péteri', 'Halászkert 1150', 'Zentai-Csiszár Éva Ibolya', '1959-06-14', '879637MA', '2209 Péteri, Halászkert 1150', 65535, '16200106-11544391', '68173797-1-3', '111111', 'aaaa@aaaa.hu'),
(11, 'Balogh Attila Károly EV', NULL, 'hu', '', '674854281-24', '2017-12-31', 5711, 'Gyula', 'Temesvári út 231.', 'Balogh Attila Károly', '1987-03-30', '884158TA', '5711 Gyula, Temesvári út 231.', 65535, '11111111-11111111', '67485428-1-2', '111111', 'aaaa@aaaa.hu'),
(13, 'Bank360 Admin', NULL, 'hu', '', '1', '2017-09-01', 1, 'a', 'a', 'a', '2017-09-01', '1', 'a', 1, '1', '1', '1', 'a@b.cd');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `custom_labels`
--

CREATE TABLE IF NOT EXISTS `custom_labels` (
`id` int(11) NOT NULL,
  `line` text NOT NULL,
  `custom_label` text NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dynamic_attributes`
--

CREATE TABLE IF NOT EXISTS `dynamic_attributes` (
  `attribute_id` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `value_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dynamic_attributes_value`
--

CREATE TABLE IF NOT EXISTS `dynamic_attributes_value` (
  `id` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `label` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `files`
--

CREATE TABLE IF NOT EXISTS `files` (
`id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_type` char(2) NOT NULL,
  `case_id` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `files`
--

INSERT INTO `files` (`id`, `filename`, `title`, `upload_date`, `document_type`, `case_id`, `active`, `user_id`) VALUES
(1, '6a58d9b79b9f88083d6b439501139544.pdf', 'teszt feltöltés', '2017-09-15 08:25:29', 'EG', 4, 1, NULL),
(2, 'd42e2e6b76e5d7b162a96061a1cdfcc1.jpg', 'jpg teszt', '2017-09-15 08:27:33', 'EG', 4, 1, NULL),
(3, '285522cf4171b3e3ff2e2650f2b3a6eb.png', 'png teszt', '2017-09-15 08:30:49', 'EG', 4, 1, NULL),
(4, '0f5fae4240654902dcf324cd64dd17d2.png', 'png', '2017-09-15 09:11:30', 'EG', NULL, 1, 157);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
`id` mediumint(8) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Admin'),
(7, 'admin_sales', 'Admin Sales'),
(8, 'partners', 'Partners');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `groups_permission`
--

CREATE TABLE IF NOT EXISTS `groups_permission` (
  `perm_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `groups_permission`
--

INSERT INTO `groups_permission` (`perm_id`, `group_id`) VALUES
(1, 1),
(2, 1),
(4, 1),
(8, 1),
(9, 1),
(37, 1),
(44, 1),
(44, 7),
(45, 1),
(45, 7),
(45, 8),
(47, 1),
(48, 1),
(67, 1),
(67, 7),
(67, 8),
(71, 1),
(72, 1),
(75, 1),
(76, 1),
(78, 1),
(78, 7),
(78, 8),
(79, 1),
(79, 7),
(79, 8),
(80, 1),
(80, 7),
(80, 8),
(81, 1),
(81, 8),
(83, 1),
(83, 8),
(86, 1),
(86, 8);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `labels`
--

CREATE TABLE IF NOT EXISTS `labels` (
`id` int(11) NOT NULL,
  `label_code` text NOT NULL,
  `page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `labels_custom`
--

CREATE TABLE IF NOT EXISTS `labels_custom` (
`id` int(11) NOT NULL,
  `label_id` int(11) NOT NULL,
  `custom_label` text NOT NULL,
  `company_id` int(11) NOT NULL,
  `lang` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `labels_custom`
--

INSERT INTO `labels_custom` (`id`, `label_id`, `custom_label`, `company_id`, `lang`) VALUES
(28, 1, 'Custom Employee Name2', 5, 'en'),
(29, 3, 'Employee Custom First Name', 5, 'en'),
(30, 4, 'Custom Employee Title', 5, 'en'),
(31, 20, 'Mission custom Home Company', 5, 'en'),
(32, 93, 'tax stat 2 custom', 5, 'en'),
(359, 1, 'Nom', 4, 'fr'),
(360, 3, 'Prénom', 4, 'fr'),
(361, 4, 'Civilté', 4, 'fr'),
(362, 5, 'Marticule', 4, 'fr'),
(363, 6, 'VIP', 4, 'fr'),
(364, 7, 'Téléphone bureau', 4, 'fr'),
(365, 8, 'Téléphone portable', 4, 'fr'),
(366, 9, 'E-mail bureau', 4, 'fr'),
(367, 10, 'Commentaires', 4, 'fr'),
(368, 11, 'Utilisateurs', 4, 'fr'),
(369, 12, 'Nom', 4, 'fr'),
(370, 13, 'Prénom', 4, 'fr'),
(371, 14, 'Relation', 4, 'fr'),
(372, 15, 'Date de Naissance', 4, 'fr'),
(373, 16, 'A charge fiscale', 4, 'fr'),
(374, 17, 'Accompagne l´expatrié', 4, 'fr'),
(375, 18, 'Pays d´origine', 4, 'fr'),
(376, 19, 'Ville d´origine', 4, 'fr'),
(377, 20, 'Société d´origine', 4, 'fr'),
(378, 21, 'Adresse Société d´origine', 4, 'fr'),
(379, 22, 'Fonction Pays d´origine', 4, 'fr'),
(380, 23, 'Supérieur hiérarchique Pays d´origine', 4, 'fr'),
(381, 24, 'Téléphone', 4, 'fr'),
(382, 25, 'Adresse email', 4, 'fr'),
(383, 26, 'Composition Familiale', 4, 'fr'),
(384, 27, 'Nom', 4, 'fr'),
(385, 28, 'Lien de parenté', 4, 'fr'),
(386, 29, 'Numéro de téléphone', 4, 'fr'),
(387, 30, 'Adresse email', 4, 'fr'),
(388, 31, 'Module Google Map', 4, 'fr'),
(389, 32, 'Commentaires', 4, 'fr'),
(390, 33, 'Pays d´accueil', 4, 'fr'),
(391, 34, 'Pays d´accueil', 4, 'fr'),
(392, 35, 'Société d´accueil', 4, 'fr'),
(393, 36, 'Adresse Société d´accueil', 4, 'fr'),
(394, 37, 'Fonction Pays d´accueil', 4, 'fr'),
(395, 38, 'Supérieur hiérarchique Pays d´accueil', 4, 'fr'),
(396, 39, 'Téléphone', 4, 'fr'),
(397, 40, 'Adresse email', 4, 'fr'),
(398, 41, 'Composition familiale', 4, 'fr'),
(399, 42, 'Nom', 4, 'fr'),
(400, 43, 'Lien de parenté', 4, 'fr'),
(401, 44, 'Numéro de téléphone', 4, 'fr'),
(402, 45, 'Adresse email', 4, 'fr'),
(403, 46, 'Module Google Map', 4, 'fr'),
(404, 47, 'Commentaires', 4, 'fr'),
(405, 33, 'Pays d´accueil', 4, 'fr'),
(406, 34, 'Pays d´accueil', 4, 'fr'),
(407, 35, 'Société d´accueil', 4, 'fr'),
(408, 36, 'Adresse Société d´accueil', 4, 'fr'),
(409, 37, 'Fonction Pays d´accueil', 4, 'fr'),
(410, 38, 'Supérieur hiérarchique Pays d´accueil', 4, 'fr'),
(411, 39, 'Téléphone', 4, 'fr'),
(412, 40, 'Adresse email', 4, 'fr'),
(413, 41, 'Composition familiale', 4, 'fr'),
(414, 42, 'Nom', 4, 'fr'),
(415, 43, 'Lien de parenté', 4, 'fr'),
(416, 44, 'Numéro de téléphone', 4, 'fr'),
(417, 45, 'Adresse email', 4, 'fr'),
(418, 46, 'Module Google Map', 4, 'fr'),
(419, 47, 'Commentaires', 4, 'fr'),
(420, 48, 'Début de mission', 4, 'fr'),
(421, 49, 'Fin prévisionnelle de la mission', 4, 'fr'),
(422, 50, 'Date réelle fin de mission', 4, 'fr'),
(423, 51, 'Statut - Politique MI', 4, 'fr'),
(424, 52, 'Gestionnaire en charge du dossier', 4, 'fr'),
(425, 53, 'RH de référence', 4, 'fr'),
(426, 54, 'Commentaires', 4, 'fr'),
(427, 55, 'Package', 4, 'fr'),
(428, 56, 'Contrat', 4, 'fr'),
(429, 57, 'Affiliation', 4, 'fr'),
(430, 58, 'Immigration', 4, 'fr'),
(431, 59, 'Déménagement', 4, 'fr'),
(432, 60, 'Relocation', 4, 'fr'),
(433, 61, 'Affiliation', 4, 'fr'),
(434, 62, 'Immigration', 4, 'fr'),
(435, 63, 'Déménagement', 4, 'fr'),
(436, 64, 'Relocation', 4, 'fr'),
(437, 65, 'Statut Sécurité Sociale', 4, 'fr'),
(438, 66, 'Date de début de validité', 4, 'fr'),
(439, 67, 'Date de fin de validité', 4, 'fr'),
(440, 68, 'Pays d´origine', 4, 'fr'),
(441, 69, 'Prestataire', 4, 'fr'),
(442, 70, 'Coordonnées', 4, 'fr'),
(443, 71, 'Type d´assistance', 4, 'fr'),
(444, 72, 'Type d´assistance', 4, 'fr'),
(445, 73, 'Date d´envoi E-mail notification départ', 4, 'fr'),
(446, 74, 'Statut fiscal', 4, 'fr'),
(447, 75, 'Commentaires', 4, 'fr'),
(448, 76, 'Début affiliation', 4, 'fr'),
(449, 77, 'Fin affiliation', 4, 'fr'),
(450, 88, 'Pays d´accueil', 4, 'fr'),
(451, 89, 'Prestataire', 4, 'fr'),
(452, 90, 'Coordonnées', 4, 'fr'),
(453, 91, 'Type d´assistance', 4, 'fr'),
(454, 92, 'Date d´envoi E-mail notification départ', 4, 'fr'),
(455, 93, 'Statut fiscal', 4, 'fr'),
(456, 78, 'Société mandatée', 4, 'fr'),
(457, 79, 'Adresse email contact', 4, 'fr'),
(458, 80, 'Garde meuble', 4, 'fr'),
(459, 81, 'Date de début de validité', 4, 'fr'),
(460, 82, 'Date de fin de validité', 4, 'fr'),
(461, 83, 'Date de début de validité', 4, 'fr'),
(462, 84, 'Date de fin de validité', 4, 'fr'),
(463, 85, 'Société mandatée', 4, 'fr'),
(464, 86, 'Adresse email contact', 4, 'fr'),
(465, 87, 'Commentaires', 4, 'fr');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
`id` tinyint(1) unsigned NOT NULL,
  `language_name` varchar(100) NOT NULL,
  `language_directory` varchar(100) NOT NULL,
  `slug` varchar(10) NOT NULL,
  `language_code` char(2) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_directory`, `slug`, `language_code`, `default`) VALUES
(1, 'English', 'english', 'en', 'en', 0),
(2, 'français', 'french', 'fr', 'fr', 0),
(3, 'magyar', 'hungarian', 'hu', 'hu', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `leads`
--

CREATE TABLE IF NOT EXISTS `leads` (
`id` int(10) unsigned NOT NULL,
  `source` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `postcode` smallint(5) unsigned NOT NULL,
  `town` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `product_category` char(2) COLLATE utf8_hungarian_ci NOT NULL,
  `bank_id` smallint(5) unsigned NOT NULL,
  `call_time` char(2) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `meeting_time` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_hungarian_ci,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `agent_id` int(10) unsigned DEFAULT NULL,
  `splitter_id` int(10) unsigned DEFAULT NULL,
  `splitting_time` datetime DEFAULT NULL,
  `lead_id` varchar(15) COLLATE utf8_hungarian_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `leads`
--

INSERT INTO `leads` (`id`, `source`, `name`, `postcode`, `town`, `street`, `phone`, `email`, `product_category`, `bank_id`, `call_time`, `meeting_time`, `comment`, `created_time`, `active`, `agent_id`, `splitter_id`, `splitting_time`, `lead_id`, `user_id`) VALUES
(5, 153, 'Teszt Lead', 8380, 'Hévíz', 'SE', '+36201111111', '1asdf@asdf.hu', 'HS', 7, 'RE', '2017-10-25 06:30:45', 'Megjegyzééésecske', '2017-10-05 12:27:40', 1, 142, 159, '2017-10-05 12:28:40', 'zuDsmePN', 159),
(8, NULL, 'Partnermáténak Szánt Lead', 1111, 'Budapest', 'asd', '+36201231321', 'aaaa@aaaa.hu', 'HS', 7, 'DE', '2017-10-05 15:43:18', '', '2017-10-05 13:43:31', 1, 161, 159, '2017-10-05 13:43:40', 'lead_id_bank360', 159),
(11, 161, 'Teszt Mátétól Jövő Lead', 2222, 'Asde', 'asd', '+36202222222', 'aaaa@aaaa.hu', 'HS', 9, 'DU', '2017-10-05 16:15:23', 'asdf', '2017-10-05 14:15:26', 1, 159, 159, '2017-10-05 14:19:01', 'cuwiwWTx', 161);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `lead_statuses`
--

CREATE TABLE IF NOT EXISTS `lead_statuses` (
`id` int(10) unsigned NOT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `status` char(3) COLLATE utf8_hungarian_ci NOT NULL,
  `comment` text COLLATE utf8_hungarian_ci,
  `reminder_time` datetime DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `lead_statuses`
--

INSERT INTO `lead_statuses` (`id`, `lead_id`, `status`, `comment`, `reminder_time`, `created_time`, `user_id`) VALUES
(5, 5, 'INV', '', NULL, '2017-10-05 13:29:31', 159),
(8, 5, 'ISI', 'hívj fel!', '2017-10-20 04:22:32', '2017-10-05 13:30:08', 159),
(11, 11, 'PNV', 'próba emlékeztető', '2017-10-05 16:22:48', '2017-10-05 14:21:59', 159),
(14, 11, 'ILZ', '', '2017-10-05 18:26:42', '2017-10-05 14:24:13', 159);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
`id` int(11) unsigned NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `normal_attributes_value`
--

CREATE TABLE IF NOT EXISTS `normal_attributes_value` (
  `id` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
`id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `definition` varchar(50) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `order` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `definition`, `active`, `order`) VALUES
(1, 'edit_users', 'can add, edit, delete a user', 1, 255),
(2, 'view_users', 'can view a user', 1, 255),
(4, 'create_users', 'can create a user', 1, 255),
(8, 'edit_companies', 'can add, edit, delete a company', 1, 20),
(9, 'view_companies', 'can view a company', 1, 20),
(37, 'view_self', 'can view the user', 1, 90),
(44, 'edit_dash', 'can add, edit, delete the dash', 1, 30),
(45, 'view_dash', 'can view the dash', 1, 30),
(47, 'edit_group', 'can add, edit, delete the group', 1, 50),
(48, 'view_group', 'can view the group', 1, 50),
(67, 'edit_self', 'able to edit own data', 1, 90),
(71, 'view_languages', 'You can see the languages', 1, 60),
(72, 'edit_languages', 'You can edit  the languages', 1, 60),
(75, 'edit_structures', NULL, 1, 80),
(76, 'view_structure', NULL, 1, 80),
(78, 'edit_cases', NULL, 1, 10),
(79, 'view_cases', NULL, 1, 10),
(80, 'create_cases', NULL, 1, 10),
(81, 'edit_files', NULL, 1, 40),
(83, 'edit_leads', NULL, 1, 70),
(86, 'view_leads', NULL, 1, 70),
(92, 'delete_users', NULL, 1, 100),
(95, 'delete_cases', NULL, 1, 10),
(98, 'create_leads', NULL, 1, 70),
(101, 'delete_leads', NULL, 1, 70),
(104, 'view_all_users', NULL, 1, 100),
(107, 'edit_all_users', NULL, 1, 100),
(110, 'view_all_cases', NULL, 1, 10),
(113, 'edit_all_cases', NULL, 1, 10),
(116, 'view_all_leads', NULL, 1, 70),
(119, 'edit_all_leads', NULL, 1, 70),
(122, 'split_leads', NULL, 1, 70),
(125, 'split_all_leads', NULL, 1, 70),
(128, 'view_structure_users', NULL, 1, 100),
(131, 'edit_structure_users', NULL, 1, 100),
(134, 'view_structure_cases', NULL, 1, 10),
(137, 'edit_structure_cases', NULL, 1, 10),
(140, 'view_structure_leads', NULL, 1, 70),
(143, 'edit_structure_leads', NULL, 1, 70),
(146, 'split_structure_leads', NULL, 1, 70);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `bank_id` smallint(5) unsigned NOT NULL,
  `product_category` char(2) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `term` int(11) unsigned DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `account_creation_fee` int(11) unsigned DEFAULT NULL,
  `account_creation_fee_discount` varchar(255) DEFAULT NULL,
  `monthly payment` int(11) unsigned DEFAULT NULL,
  `account_fee` varchar(255) DEFAULT NULL,
  `contract_amount` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `stat_dates`
--

CREATE TABLE IF NOT EXISTS `stat_dates` (
`id` int(11) NOT NULL,
  `month` text NOT NULL,
  `month_date` text NOT NULL,
  `lang_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `stat_dates`
--

INSERT INTO `stat_dates` (`id`, `month`, `month_date`, `lang_id`) VALUES
(1, 'January', '01', 5),
(2, 'February', '02', 5),
(3, 'March', '03', 5),
(4, 'April', '04', 5),
(5, 'May', '05', 5),
(6, 'June', '06', 5),
(7, 'July', '07', 5),
(8, 'August', '08', 5),
(9, 'September', '09', 5),
(10, 'October', '10', 5),
(11, 'November', '11', 5),
(12, 'December', '12', 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `structures`
--

CREATE TABLE IF NOT EXISTS `structures` (
`id` smallint(5) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `product_categories` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `structures`
--

INSERT INTO `structures` (`id`, `title`, `product_categories`) VALUES
(3, 'Kiemelt Lakástakarék Hálózat', 'HS'),
(5, 'Bank360 Admin', 'HS,ML,PL,CA');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `uploaded_files`
--

CREATE TABLE IF NOT EXISTS `uploaded_files` (
`id` int(11) NOT NULL,
  `created` date NOT NULL,
  `name` text NOT NULL,
  `employee_id` int(11) NOT NULL,
  `mission_id` int(11) NOT NULL,
  `deleted` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) unsigned NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `user_picture` text,
  `default_lang` text NOT NULL,
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'I',
  `legal_relation` char(1) DEFAULT NULL,
  `birth_place` varchar(255) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `mothers_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `id_card_no` varchar(8) DEFAULT NULL,
  `address_card_no` varchar(8) DEFAULT NULL,
  `company_reg_no` varchar(12) DEFAULT NULL,
  `tax_no` varchar(13) DEFAULT NULL,
  `education` char(1) DEFAULT NULL,
  `education_date` date DEFAULT NULL,
  `mnb_no` varchar(15) DEFAULT NULL,
  `comment` text CHARACTER SET utf8 COLLATE utf8_hungarian_ci,
  `product_categories` varchar(50) DEFAULT NULL,
  `structure_id` smallint(5) unsigned DEFAULT NULL,
  `superior_id` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `user_picture`, `default_lang`, `level`, `status`, `legal_relation`, `birth_place`, `birth_date`, `mothers_name`, `id_card_no`, `address_card_no`, `company_reg_no`, `tax_no`, `education`, `education_date`, `mnb_no`, `comment`, `product_categories`, `structure_id`, `superior_id`) VALUES
(1, '127.0.0.1', 'admin@bank360.hu', '$2y$08$0rhD8Hqhlk3xX5xRphDtzejAZmJnoVuluQF69Di7G4MucOv.zcat6', '', 'admin@admin.com', '', NULL, NULL, 'gUald0tMYXsAQyWAiy97/O', 1268889823, 1507539726, 1, 'Admin', 'Bank360', 1, NULL, 'f5d9d3eeb4940d25bd2ce756d765d644.jpg', 'hu', 6, 'A', 'O', NULL, NULL, 'Anyja Neve', '.', '.', '.', '.', 'S', '2011-01-02', '.', '', 'ML', 1, 0),
(114, '145.236.13.154', 'joinpaintball@bank360.hu', '$2y$08$t7RjlU5pj.P4pkdfzUcMCO8T8.76ZOOxQjkqkG6RtrPXWz6adIvei', NULL, 'joinpaintball@gmail.com', NULL, NULL, NULL, NULL, 1459429607, 1461058480, 0, 'Istvan', 'Kaholics', 1, '', '', 'hu', 0, '', '', NULL, NULL, '', '', '', NULL, '', '0', '2011-01-02', NULL, NULL, '', 1, 69),
(142, '84.0.94.253', 'hack.gyoergy.tamas@bank360.hu', '$2y$08$9omydzn5Oto6IWCBf.tcsONxDbkSzXw.vCZYfYNEC1SQZny165K1O', NULL, 'hack.gyoergy.tamas@bank360.hu', NULL, NULL, NULL, NULL, 1505387606, 1505809200, 1, 'György Tamás', 'Hack', 6, NULL, NULL, 'hu', 6, 'A', 'O', NULL, NULL, 'Hegyi Erzsébet', '396187AE', '476513LE', '01-09-987429', '23977750-2-41', 'M', '2012-10-11', '182060/2017', '', 'HS', 3, 0),
(148, '84.0.94.253', 'menyhei.adam@bank360.hu', '$2y$08$qQ3L7NI.T7Fq/eNjMZDJOOChFA5qufDIgUbaFTWLz1.gc3090TmQy', NULL, 'menyhei.adam@bank360.hu', NULL, NULL, NULL, NULL, 1505392848, 1505464557, 1, 'Ádám', 'Menyhei', 7, NULL, NULL, 'hu', 5, 'A', 'E', NULL, NULL, 'Kazinczi Márta', '2679521T', '280097LC', '13-09-189162', '26127435-2-13', 'M', '2013-11-04', '00025661', '', 'HS', 3, 142),
(152, '84.0.94.253', 'racz.zoltan@bank360.hu', '$2y$08$/LLfrS2JK3XF33Ac734ZlOnHUrMS7Ak.hhnreY2ZaYPDRz.IIicpe', NULL, 'racz.zoltan@bank360.hu', NULL, NULL, NULL, NULL, 1505393233, NULL, 1, 'Zoltán', 'Rácz', 7, NULL, NULL, 'hu', 4, 'A', 'E', NULL, NULL, 'Terdik Magdolna', '509202IA', '103355LC', '13-09-189162', '26127435-2-13', 'S', '2005-06-28', 'BGAZD112/05', '', 'HS', 3, 148),
(153, '84.0.94.253', 'frey.zsoltne@bank360.hu', '$2y$08$NUABD/n4Nr4HdbrFGi/JF.TgMNxMo2nkweHNC7FEuBM0.XlULFly6', NULL, 'frey.zsoltne@bank360.hu', NULL, NULL, NULL, NULL, 1505393570, NULL, 1, 'Zsoltné', 'Frey', 8, NULL, NULL, 'hu', 3, 'A', 'E', NULL, NULL, 'Németh Ilona', '794861IA', '161989LC', '01-09-956752', '23180134-1-41', 'M', '2012-11-13', '00021634', '', 'HS', 3, 142),
(154, '84.0.94.253', 'varga.edit@bank360.hu', '$2y$08$MsnfkuvCsXN51dGi.VKO7eIZfGpoBC9g6tl7xX/Gw.fkLuDKxwx7a', NULL, 'varga.edit@bank360.hu', NULL, NULL, NULL, NULL, 1505394894, NULL, 1, 'Edit', 'Varga', 9, NULL, NULL, 'hu', 3, 'A', 'E', NULL, NULL, 'Nemes Judit', '072302AE', '954962JL', '01-09-303498', '26130248-2-42', 'M', '2013-09-19', '00025092', '', 'HS', 3, 148),
(155, '84.0.94.253', 'zentai-csiszar.eva.ibolya@bank360.hu', '$2y$08$g7DZyNlG8s7QMNnjoUlLr.u6BiMfmrxTwFDkvib56GYnTDzTvnbje', NULL, 'zentai-csiszar.eva.ibolya@bank360.hu', NULL, NULL, NULL, NULL, 1505395208, NULL, 1, 'Éva Ibolya', 'Zentai-Csiszár', 10, NULL, NULL, 'hu', 3, 'A', 'S', NULL, NULL, 'Debreceni Klára', '879637MA', '101102XL', '51346094', '68173797-1-33', 'M', '2011-08-03', '00015094', '', 'HS', 3, 152),
(156, '84.0.94.253', 'balogh.attila.karoly@bank360.hu', '$2y$08$LgpdfPcE7KPmY967qrVy/ei/u4KHGZ8ytmF6HFW0u3bmcLIoCDspa', NULL, 'balogh.attila.karoly@bank360.hu', NULL, NULL, NULL, NULL, 1505395859, NULL, 1, 'Attila Károly', 'Balogh', 11, NULL, NULL, 'hu', 1, 'A', 'S', NULL, NULL, 'Bede Juliana Susana', '884158TA', '941460LC', '50302132', '67485428-1-24', 'M', '2017-12-31', '11111111', '', 'HS', 3, 154),
(159, '84.0.94.253', 'mate.ivanyi@bank360.hu', '$2y$08$q4nwUEEF6KLhZEx9.gZu/OTFlczwv3Frmy2Xi.ztSfkCKhNIVZHoe', NULL, 'mate.ivanyi@bank360.hu', NULL, NULL, NULL, NULL, 1505467506, 1507205977, 1, 'Iványi', 'Máté', 13, '1', NULL, 'hu', 6, 'A', 'E', 'Kórház', '2017-10-17', 'a', '111111AA', '111111AA', NULL, '8888888888', 'S', '2017-09-01', '1', '', 'HS', 3, 0),
(160, '84.0.94.253', 'levente.suranyi@bank360.hu', '$2y$08$KZMjIH7U9jXgorzpO5luouebaFXbzvkjMk68GuDgVZjw3je/gkyOS', NULL, 'levente.suranyi@bank360.hu', NULL, NULL, NULL, NULL, 1505467725, NULL, 1, 'Surányi', 'Levente', 13, NULL, NULL, 'hu', 6, 'A', 'E', NULL, NULL, 'a', '1', '1', '1', '1', 'S', '2017-09-01', '1', '', 'PL', 5, 0),
(161, '195.228.191.51', 'partner.mate@bank360.hu', '$2y$08$aNulUayuYWHyQbSYzl4rVeakcPjBk11BuyzkiWWcU5K6GviMIdDKW', NULL, 'partner.mate@bank360.hu', NULL, NULL, NULL, NULL, 1507210869, 1507212859, 1, 'Máté', 'Partner', 13, '1', NULL, 'hu', 3, 'A', 'E', 'asd', '2017-10-30', 'a', '123123AS', '123123AS', NULL, '8888888888', 'M', '2017-10-23', 'asdf', '', 'HS', 3, 159);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_contact_info`
--

CREATE TABLE IF NOT EXISTS `users_contact_info` (
`id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim_is` tinyint(1) unsigned DEFAULT NULL,
  `levelezes_iranyitoszam` int(11) DEFAULT NULL,
  `levelezes_varos` varchar(255) DEFAULT NULL,
  `levelezes_utca_hazszam` varchar(255) DEFAULT NULL,
  `mobiltelefonszam` varchar(20) DEFAULT NULL,
  `email_privat` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_contact_info`
--

INSERT INTO `users_contact_info` (`id`, `user_id`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim_is`, `levelezes_iranyitoszam`, `levelezes_varos`, `levelezes_utca_hazszam`, `mobiltelefonszam`, `email_privat`) VALUES
(5, 140, NULL, '', '', NULL, NULL, '', '', '', ''),
(6, 141, NULL, '', '', NULL, NULL, '', '', '', ''),
(8, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(9, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(10, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(11, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(12, 102, 2222, 'Békés', 'Utca u. 15.', 1, NULL, NULL, NULL, '', 'set@erhazukdfh.er'),
(13, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(14, 102, 2222, 'Békés', 'Utca u. 15.', 1, NULL, NULL, NULL, '', 'set@erhazukdfh.er'),
(15, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(16, 69, 2222, 'Budapest', 'Utca u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@erhsgjkb.er'),
(17, 1, 1061, 'Budapest', 'Andrássy út 10.', 1, NULL, NULL, NULL, '+3612345678', 'info@bank360.hu'),
(18, 142, 1138, 'Budapest', 'Váci út 170/c', 1, NULL, '', '', '+36309321580', 'funtom12@gmail.com'),
(19, 147, 1138, 'Budapest', 'Váci út 170/c', NULL, 2083, 'Solymár', 'Erdő utca 35.', '+36309321580', 'funtom12@gmail.com'),
(20, 147, 1138, 'Budapest', 'Váci út 170/c', NULL, 2083, 'Solymár', 'Erdő utca 35.', '+36309321580', 'funtom12@gmail.com'),
(21, 142, 1138, 'Budapest', 'Váci út 170/c', 1, 1138, 'Budapest', 'Váci út 170/c', '+36309321580', 'funtom12@gmail.com'),
(22, 142, 1138, 'Budapest', 'Váci út 170/c', 1, 1138, 'Budapest', 'Váci út 170/c', '+36309321580', 'funtom12@gmail.com'),
(23, 148, 2724, 'Újlengyel', 'Petőfi S. u. 48', NULL, 1074, 'Budapest', 'Alsóerdősor utca 32 2/22', '+36709474471', 'aaaa@aaaa.hu'),
(24, 152, 2724, 'Újlengyel', 'Petőfi S. u. 48', NULL, 1074, 'Budapest', 'Alsóerdősor utca 32 2/22', '+36309428664', 'aaaa@aaaa.hu'),
(25, 153, 1036, 'Budapest', 'Kolosy tér 5-6. fsz 14', 1, NULL, NULL, NULL, '+36203635716', 'aaaa@aaaa.hu'),
(26, 154, 1173, 'Budapest', 'Vízhordó utca 52.', 1, NULL, NULL, NULL, '+36703911015', 'aaaa@aaaa.hu'),
(27, 155, 2209, 'Péteri', 'Halászkert 1150', NULL, 1043, 'Budapest', 'Erzsébet utca 18.', '+36703842151', 'aaaa@aaaa.hu'),
(28, 156, 5711, 'Gyula', 'Temesvári út 231.', 1, NULL, NULL, NULL, '+36704888185', 'aaaa@aaaa.hu'),
(29, 158, 1, 'a', 'a', 1, NULL, NULL, NULL, '1', 'mate.ivanyi@bank360.hu'),
(30, 159, 1111, 'Budapest', 'a', 1, NULL, NULL, NULL, '+36201111111', 'mate.ivanyi@bank360.hu'),
(31, 160, 1, 'a', 'a', 1, NULL, NULL, NULL, '1', 'levente.suranyi@bank360.hu'),
(32, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(35, 161, 1111, 'Budapest', 'a', 1, NULL, NULL, NULL, '+36201111111', 'aaaa@aaaa.hu');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
`id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=452 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(404, 1, 1),
(360, 114, 1),
(441, 142, 8),
(420, 148, 8),
(422, 152, 8),
(424, 153, 8),
(426, 154, 8),
(428, 155, 8),
(430, 156, 8),
(443, 159, 1),
(437, 160, 1),
(449, 161, 8);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_sales_codes`
--

CREATE TABLE IF NOT EXISTS `users_sales_codes` (
`id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `bank_id` smallint(5) unsigned NOT NULL,
  `kapcsolattarto_fiok_neve` varchar(255) DEFAULT NULL,
  `kapcsolattarto_fiok_kodja` varchar(255) DEFAULT NULL,
  `kapcsolattarto_fiok_cime` varchar(255) DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `azonosito` varchar(255) DEFAULT NULL,
  `product_categories` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_sales_codes`
--

INSERT INTO `users_sales_codes` (`id`, `user_id`, `bank_id`, `kapcsolattarto_fiok_neve`, `kapcsolattarto_fiok_kodja`, `kapcsolattarto_fiok_cime`, `datum`, `azonosito`, `product_categories`) VALUES
(2, 103, 9, 'Kakukk Fiók Név', 'Fiók kód', 'Lombcsúcs 14.', '2016-09-21', '84/2', 'HS'),
(3, 147, 7, 'FIÓK', '123456', 'FIÓK Címe', '2017-12-31', 'CCCC0728', 'HS'),
(4, 142, 7, 'FIÓK', 'KÓD', 'CÍM', '2017-12-31', 'CCCC0728', 'HS');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `usertracking`
--

CREATE TABLE IF NOT EXISTS `usertracking` (
`id` int(11) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `user_identifier` varchar(255) NOT NULL,
  `request_uri` text NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  `client_ip` varchar(50) NOT NULL,
  `client_user_agent` text NOT NULL,
  `referer_page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
 ADD UNIQUE KEY `attribute_id` (`attribute_id`,`entity_id`), ADD KEY `attribute_id_2` (`attribute_id`);

--
-- Indexes for table `attributes_default_labels`
--
ALTER TABLE `attributes_default_labels`
 ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cases_beneficiary`
--
ALTER TABLE `cases_beneficiary`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cases_client_data`
--
ALTER TABLE `cases_client_data`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cases_common`
--
ALTER TABLE `cases_common`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `custom_labels`
--
ALTER TABLE `custom_labels`
 ADD KEY `id` (`id`);

--
-- Indexes for table `dynamic_attributes`
--
ALTER TABLE `dynamic_attributes`
 ADD PRIMARY KEY (`attribute_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups_permission`
--
ALTER TABLE `groups_permission`
 ADD PRIMARY KEY (`perm_id`,`group_id`);

--
-- Indexes for table `labels`
--
ALTER TABLE `labels`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `labels_custom`
--
ALTER TABLE `labels_custom`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`), ADD KEY `id_2` (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `lead_id` (`lead_id`), ADD KEY `agent_id` (`agent_id`), ADD KEY `splitter_id` (`splitter_id`), ADD KEY `user_id` (`user_id`), ADD KEY `source` (`source`);

--
-- Indexes for table `lead_statuses`
--
ALTER TABLE `lead_statuses`
 ADD PRIMARY KEY (`id`), ADD KEY `lead_id` (`lead_id`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
 ADD PRIMARY KEY (`id`), ADD KEY `id_index` (`id`), ADD KEY `order` (`order`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`), ADD KEY `bank_id` (`bank_id`);

--
-- Indexes for table `stat_dates`
--
ALTER TABLE `stat_dates`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `structures`
--
ALTER TABLE `structures`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_contact_info`
--
ALTER TABLE `users_contact_info`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`), ADD KEY `fk_users_groups_users1_idx` (`user_id`), ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- Indexes for table `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
 ADD PRIMARY KEY (`id`), ADD KEY `bank_id` (`bank_id`);

--
-- Indexes for table `usertracking`
--
ALTER TABLE `usertracking`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `cases_beneficiary`
--
ALTER TABLE `cases_beneficiary`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cases_client_data`
--
ALTER TABLE `cases_client_data`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cases_common`
--
ALTER TABLE `cases_common`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `custom_labels`
--
ALTER TABLE `custom_labels`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `labels`
--
ALTER TABLE `labels`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `labels_custom`
--
ALTER TABLE `labels_custom`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=466;
--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
MODIFY `id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `lead_statuses`
--
ALTER TABLE `lead_statuses`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=149;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stat_dates`
--
ALTER TABLE `stat_dates`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `structures`
--
ALTER TABLE `structures`
MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=164;
--
-- AUTO_INCREMENT for table `users_contact_info`
--
ALTER TABLE `users_contact_info`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=452;
--
-- AUTO_INCREMENT for table `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `usertracking`
--
ALTER TABLE `usertracking`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `leads`
--
ALTER TABLE `leads`
ADD CONSTRAINT `leads_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
ADD CONSTRAINT `leads_ibfk_2` FOREIGN KEY (`splitter_id`) REFERENCES `users` (`id`),
ADD CONSTRAINT `leads_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
ADD CONSTRAINT `leads_ibfk_4` FOREIGN KEY (`source`) REFERENCES `users` (`id`);

--
-- Megkötések a táblához `lead_statuses`
--
ALTER TABLE `lead_statuses`
ADD CONSTRAINT `lead_statuses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
ADD CONSTRAINT `lead_statuses_ibfk_3` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`);

--
-- Megkötések a táblához `login_attempts`
--
ALTER TABLE `login_attempts`
ADD CONSTRAINT `login_attempts_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Megkötések a táblához `products`
--
ALTER TABLE `products`
ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`id`);

--
-- Megkötések a táblához `users_groups`
--
ALTER TABLE `users_groups`
ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Megkötések a táblához `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
ADD CONSTRAINT `users_sales_codes_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
