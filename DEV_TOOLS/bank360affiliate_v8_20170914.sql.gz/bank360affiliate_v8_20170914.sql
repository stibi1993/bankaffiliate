-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2017. Sze 14. 09:35
-- Kiszolgáló verziója: 5.7.14-log
-- PHP verzió: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `bank360affiliate`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes`
--

CREATE TABLE `attributes` (
  `attribute_id` int(11) NOT NULL,
  `entity_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes_custom_labels`
--

CREATE TABLE `attributes_custom_labels` (
  `attribute_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `label` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `attributes_default_labels`
--

CREATE TABLE `attributes_default_labels` (
  `attribute_id` int(11) NOT NULL,
  `label` int(11) NOT NULL,
  `lang_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `banks`
--

CREATE TABLE `banks` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `active` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `home_savings` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `banks`
--

INSERT INTO `banks` (`id`, `title`, `active`, `home_savings`) VALUES
(1, 'Aegon Lakástakarék', 1, 1),
(2, 'Budapest Bank', 1, 0),
(3, 'Cetelem', 1, 0),
(4, 'CIB Bank', 1, 0),
(5, 'Cofidis', 1, 0),
(6, 'ERSTE Bank', 1, 0),
(7, 'ERSTE Lakástakarék', 1, 1),
(8, 'FHB Bank', 1, 0),
(9, 'Fundamenta', 1, 1),
(10, 'KH Bank', 1, 0),
(11, 'MKB Bank', 1, 0),
(12, 'OTP Bank', 1, 0),
(13, 'OTP Lakástakarék', 1, 1),
(14, 'Provident', 1, 0),
(15, 'Raiffeisen Bank', 1, 0),
(16, 'Sberbank', 1, 0),
(17, 'Takarék Bank', 1, 0),
(18, 'UniCredit Bank', 1, 0),
(19, 'Oney', 1, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_beneficiary`
--

CREATE TABLE `cases_beneficiary` (
  `id` int(11) UNSIGNED NOT NULL,
  `case_id` int(11) UNSIGNED DEFAULT NULL,
  `van_kedvezmenyezett` tinyint(1) UNSIGNED DEFAULT NULL,
  `nev` varchar(255) DEFAULT NULL,
  `szuletesi_nev` varchar(255) DEFAULT NULL,
  `anyja_szuletesi_neve` varchar(255) DEFAULT NULL,
  `szuletesi_hely` varchar(255) DEFAULT NULL,
  `szuletesi_ido` date DEFAULT NULL,
  `adoazonosito_jel` int(11) DEFAULT NULL,
  `allampolgarsag` varchar(255) DEFAULT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim` varchar(255) DEFAULT NULL,
  `telefonszam` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_beneficiary`
--

INSERT INTO `cases_beneficiary` (`id`, `case_id`, `van_kedvezmenyezett`, `nev`, `szuletesi_nev`, `anyja_szuletesi_neve`, `szuletesi_hely`, `szuletesi_ido`, `adoazonosito_jel`, `allampolgarsag`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim`, `telefonszam`) VALUES
(1, 1, 1, 'Kedv Név', 'Kedv Név', 'An', 'Otthon', '1961-09-23', 25415552, 'magyar', 1254, 'Budafok', 'Levél u. 54.', 'Lev cím', '6254154545');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_client_data`
--

CREATE TABLE `cases_client_data` (
  `id` int(11) UNSIGNED NOT NULL,
  `case_id` int(11) UNSIGNED DEFAULT NULL,
  `ugyfel_forras` varchar(5) DEFAULT NULL,
  `ugyfel_tipusa` char(2) DEFAULT NULL,
  `nev` varchar(255) DEFAULT NULL,
  `ceg_kepviselojenek_neve` varchar(255) DEFAULT NULL,
  `szuletesi_nev` varchar(255) DEFAULT NULL,
  `anyja_szuletesi_neve` varchar(255) DEFAULT NULL,
  `szuletesi_hely` varchar(255) DEFAULT NULL,
  `szuletesi_ido` date DEFAULT NULL,
  `adoszam` int(11) DEFAULT NULL,
  `azonosito_okmany_tipusa` char(2) DEFAULT NULL,
  `azonosito_okmany_szama` varchar(255) DEFAULT NULL,
  `allampolgarsag` varchar(255) DEFAULT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim` varchar(255) DEFAULT NULL,
  `telefonszam` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `epulet_cime` varchar(255) DEFAULT NULL,
  `lakasok_szama` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_client_data`
--

INSERT INTO `cases_client_data` (`id`, `case_id`, `ugyfel_forras`, `ugyfel_tipusa`, `nev`, `ceg_kepviselojenek_neve`, `szuletesi_nev`, `anyja_szuletesi_neve`, `szuletesi_hely`, `szuletesi_ido`, `adoszam`, `azonosito_okmany_tipusa`, `azonosito_okmany_szama`, `allampolgarsag`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim`, `telefonszam`, `email`, `epulet_cime`, `lakasok_szama`) VALUES
(1, 1, 'sajat', 'TE', 'Első Ügyfél', 'Képviselő', 'Első Ügyfél', 'Anya név', 'Budapest', '1984-09-05', 12541321, 'VE', '3543435', 'magyar', 2222, 'Budapest', 'Alma u. 15.', '1001 Budapest, Kolos u. 11.', '354343543', 'elso.ugyfel@hotmail.com', 'Épület cím', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cases_common`
--

CREATE TABLE `cases_common` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `bank_id` smallint(5) UNSIGNED DEFAULT NULL,
  `product_category` char(2) DEFAULT NULL,
  `penztar` varchar(255) DEFAULT NULL,
  `szerzodes_szam` varchar(255) DEFAULT NULL,
  `szerzodeses_osszeg_emeles` tinyint(1) UNSIGNED DEFAULT NULL,
  `ugyfelelegedettsegi_lap_sorszama` varchar(255) DEFAULT NULL,
  `ugyfelelegedettsegi_lap_beerkezese` date DEFAULT NULL,
  `igenyfelmero_adatlap_sorszama` varchar(255) DEFAULT NULL,
  `igenyfelmero_adatlap_beerkezese` date DEFAULT NULL,
  `szerzodeskotes_datuma` date DEFAULT NULL,
  `varhato_indulas_datuma` date DEFAULT NULL,
  `befizetes_allapota` varchar(255) DEFAULT NULL,
  `termekcsalad` varchar(255) DEFAULT NULL,
  `futamido_ev` tinyint(2) UNSIGNED DEFAULT NULL,
  `futamido_ho` tinyint(3) UNSIGNED DEFAULT NULL,
  `befizetes_modja` varchar(255) DEFAULT NULL,
  `szamlanyitasi_dij` int(11) UNSIGNED DEFAULT NULL,
  `szamlanyitasi_dij_kedvezmeny` varchar(255) DEFAULT NULL,
  `havi_befizetes` int(11) UNSIGNED DEFAULT NULL,
  `szamlavezetesi_dij` varchar(255) DEFAULT NULL,
  `ltp_szerzodes_osszege` varchar(255) DEFAULT NULL,
  `megjegyzes` text CHARACTER SET utf8 COLLATE utf8_hungarian_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `cases_common`
--

INSERT INTO `cases_common` (`id`, `user_id`, `bank_id`, `product_category`, `penztar`, `szerzodes_szam`, `szerzodeses_osszeg_emeles`, `ugyfelelegedettsegi_lap_sorszama`, `ugyfelelegedettsegi_lap_beerkezese`, `igenyfelmero_adatlap_sorszama`, `igenyfelmero_adatlap_beerkezese`, `szerzodeskotes_datuma`, `varhato_indulas_datuma`, `befizetes_allapota`, `termekcsalad`, `futamido_ev`, `futamido_ho`, `befizetes_modja`, `szamlanyitasi_dij`, `szamlanyitasi_dij_kedvezmeny`, `havi_befizetes`, `szamlavezetesi_dij`, `ltp_szerzodes_osszege`, `megjegyzes`) VALUES
(1, 102, 1, 'HS', NULL, '125484552', 0, '44415', '2017-09-05', '646464', '2017-09-12', '2017-09-20', '2017-09-12', 'FV', 'Aegon Otthon 5 LSZB10', 5, 60, 'CS', 0, 'EHB', 545412, 'Aegon Otthon 5 LSZB09', '1925000', 'dfz dtzik');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `company_name` text NOT NULL,
  `company_description` text,
  `default_language` int(11) NOT NULL,
  `company_logo` text NOT NULL,
  `tax_no` varchar(13) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `fundation_date` date DEFAULT NULL,
  `reg_office_postcode` smallint(5) UNSIGNED DEFAULT NULL,
  `reg_office_town` varchar(50) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `reg_office_street` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_birth_date` date DEFAULT NULL,
  `representative_id_card_no` varchar(8) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `representative_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `teaor` smallint(5) UNSIGNED DEFAULT NULL,
  `bank_account_no` varchar(26) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `reg_no` varchar(12) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `company_description`, `default_language`, `company_logo`, `tax_no`, `fundation_date`, `reg_office_postcode`, `reg_office_town`, `reg_office_street`, `representative_name`, `representative_birth_date`, `representative_id_card_no`, `representative_address`, `teaor`, `bank_account_no`, `reg_no`, `phone`, `email`) VALUES
(1, 'Company 1', '', 0, '43371f960d3b667cfed04742cb166bc9.png', 'ADOSZAM', '2010-06-10', 1108, 'Budapest', 'Gitár u. 1', 'Képviselő Fánk', '1977-09-09', '3413453', '5454 Tököl, Ököl u. 5.', 2514, '64454555-55555555-55555555', '21-21-21212', '+3612545552', 'dfgh@sdfg.hg'),
(4, 'Company 2', '', 0, '245035bffce8a4af48e5ec8a5e798dc0.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Company 3', '', 0, '1db34561782f70ea15371a60b0a353b3.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `custom_labels`
--

CREATE TABLE `custom_labels` (
  `id` int(11) NOT NULL,
  `line` text NOT NULL,
  `custom_label` text NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dynamic_attributes`
--

CREATE TABLE `dynamic_attributes` (
  `attribute_id` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `value_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `dynamic_attributes_value`
--

CREATE TABLE `dynamic_attributes_value` (
  `id` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `label` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `document_type` text NOT NULL,
  `case_id` int(11) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `files`
--

INSERT INTO `files` (`id`, `filename`, `title`, `upload_date`, `document_type`, `case_id`, `status`, `user_id`) VALUES
(1, '7e1a96cd84dbb1a38a7c25243b9b3e65.pdf', 'L\'expatriation_au_fÃ©minin[1].pdf', '2016-01-18 11:38:33', 'package', 0, 0, 21),
(2, 'bca4c850d1ecd0adb534d7ff605fa0ef.pdf', 'Presentation RHExpat 2015.pdf', '2016-01-12 12:26:47', 'package', 0, 1, 21),
(3, '43d49414880afd4f7b03ac2a8faabb4f.pdf', 'technical-notice-TIKKA-RXP-1.pdf', '2016-01-15 16:20:31', 'package', 2, 1, 1),
(4, 'dbfe9a0c461e0cc0e9616072dd019772.pdf', 'lista_2015_12_21_10_47_52.pdf', '2016-01-15 16:21:25', 'package', 2, 1, 1),
(11, 'dd433091b6c34524ae085d0bf7624bf8.pdf', 'banner tutorial.pdf', '2016-01-18 12:06:43', 'package', 10, 0, 1),
(12, '659888b14e760f6ac4f39b02fce88856.pdf', 'Szerverek_átadása.pdf', '2016-01-18 12:08:11', 'package', 10, 0, 1),
(13, 'a9cf14f23ff21e354884c67fd01a9bc6.pdf', 'logo_RH_2014.pdf', '2016-01-25 11:43:15', 'package', 17, 1, 102),
(14, '282dce6fa30a8f6128c310efe503268b.pdf', 'RH_logo_emploi.pdf', '2016-01-25 11:43:53', 'package', 17, 1, 102),
(15, 'bfa072319b997ab42b7f3f1fae28526f.pdf', 'logo_RH_2014.pdf', '2016-01-25 11:44:06', 'social', 17, 1, 102),
(16, '452b0347035fc0a19be5806c5437cc4e.pdf', 'logo_RH_2014.pdf', '2016-01-29 09:53:27', 'package', 18, 1, 102),
(17, '6183f31bda0d562bd9693130c653c3d8.pdf', 'benner tutorial.pdf', '2016-02-09 14:47:04', 'package', 13, 0, 1),
(18, '6fc93bce3356c75c9a65e6bf533c0105.pdf', 'benner tutorial.pdf', '2016-02-09 14:47:07', 'package', 13, 0, 1),
(19, '66e790995c868fe596761afc7bd800e8.pdf', 'Tablazat_2016.pdf', '2016-02-09 14:59:28', 'package', 13, 0, 1),
(20, '124ce27a5dae0dd7e8baf6db27293696.pdf', 'Igazolofuzet_2016.pdf', '2016-02-09 14:59:17', 'package', 13, 1, 1),
(21, '16ff0386a6c16c51d033a640d6442f6d.pdf', 'Tablazat_2016.pdf', '2016-02-09 14:59:46', 'package', 13, 1, 1),
(22, '69895462179bf665882e7c146315859c.pdf', 'transavia-boardingpass-erwan-allene-3.pdf', '2016-02-12 11:46:54', 'package', 13, 0, 1),
(23, 'da890a8a2e9b91a487fef995054ab1e6.pdf', 'BoardingPass-12.pdf', '2016-02-12 11:46:45', 'package', 13, 0, 1),
(24, 'faa02cef46919451ae2a170451fa39d8.pdf', 'elbow&wrist joint complex of AAPY.pdf', '2016-02-12 11:47:03', 'social', 13, 0, 1),
(25, '351770b7d834fdcce53a624ef3efd482.pdf', 'transavia-boardingpass-erwan-allene-3.pdf', '2016-02-12 11:46:59', 'social', 13, 0, 1),
(26, '1453b2f48c3a5f77716656e15a7d3bbf.pdf', 'À propos des piles.pdf', '2016-02-12 11:47:20', 'relocation', 13, 1, 1),
(27, '252043e938997949697ddf25d9c2438e.pdf', 'AT__B2CFR1000000861.pdf', '2016-02-12 11:47:35', 'relocation', 13, 1, 1),
(28, '99dc47cbf3d975e9d3209249b70810a6.pdf', 'À propos des piles.pdf', '2016-02-12 11:50:43', 'package', 25, 0, 111),
(29, '893e9c77c297c7565fc32a5d227e8a5e.pdf', 'adsl_felmondo_nyilatkozat.pdf', '2016-02-12 11:50:39', 'package', 25, 0, 111),
(30, '85a400a55babcc646250c7546dbdc157.pdf', 'Boarding-pass AF.pdf', '2016-02-12 11:50:34', 'social', 25, 0, 111),
(31, '7041b5c8ef21c5aa267183e04e4c0534.pdf', 'Application12270565.pdf', '2016-02-12 11:50:27', 'social', 25, 0, 111),
(32, 'f1812ed2c6cb56987652258a13a491e0.pdf', 'BoardingPass.pdf', '2016-02-12 11:50:46', 'relocation', 25, 0, 111),
(33, '1d4378f1fe68b8af489bd6e664e5a7d8.pdf', 'BoardingPass-2.pdf', '2016-02-12 11:50:49', 'relocation', 25, 0, 111);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Admin'),
(7, 'admin_sales', 'Admin Sales'),
(8, 'partners', 'Partners');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `groups_permission`
--

CREATE TABLE `groups_permission` (
  `perm_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `groups_permission`
--

INSERT INTO `groups_permission` (`perm_id`, `group_id`) VALUES
(1, 1),
(1, 2),
(1, 4),
(1, 6),
(2, 1),
(2, 2),
(2, 4),
(2, 6),
(3, 1),
(3, 2),
(3, 4),
(3, 6),
(4, 1),
(4, 2),
(4, 4),
(4, 6),
(5, 2),
(5, 4),
(6, 2),
(6, 4),
(7, 2),
(7, 4),
(8, 1),
(9, 1),
(10, 1),
(14, 2),
(14, 4),
(15, 2),
(15, 4),
(15, 5),
(16, 2),
(16, 4),
(16, 5),
(17, 2),
(17, 4),
(18, 2),
(18, 4),
(19, 2),
(19, 4),
(20, 2),
(20, 4),
(21, 2),
(21, 4),
(21, 5),
(22, 2),
(22, 4),
(22, 5),
(23, 6),
(24, 6),
(25, 6),
(33, 4),
(33, 6),
(34, 4),
(34, 6),
(35, 4),
(35, 6),
(36, 1),
(36, 2),
(36, 4),
(36, 6),
(37, 1),
(37, 2),
(37, 4),
(37, 6),
(39, 1),
(39, 2),
(39, 4),
(39, 6),
(40, 2),
(40, 6),
(42, 2),
(42, 5),
(42, 6),
(43, 2),
(43, 4),
(43, 5),
(44, 1),
(44, 2),
(44, 4),
(44, 6),
(44, 7),
(45, 1),
(45, 2),
(45, 4),
(45, 6),
(46, 1),
(46, 6),
(47, 1),
(47, 6),
(48, 1),
(48, 6),
(49, 2),
(49, 4),
(49, 6),
(50, 2),
(50, 4),
(50, 5),
(50, 6),
(51, 2),
(51, 4),
(51, 5),
(51, 6),
(53, 2),
(53, 4),
(53, 5),
(54, 2),
(54, 4),
(54, 5),
(55, 1),
(55, 2),
(55, 4),
(55, 6),
(56, 6),
(59, 5),
(60, 2),
(60, 4),
(61, 2),
(61, 4),
(62, 2),
(62, 4),
(63, 2),
(63, 5),
(65, 5),
(67, 1),
(67, 7),
(68, 5),
(69, 4),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(77, 7),
(77, 8),
(78, 7),
(78, 8),
(79, 7),
(79, 8),
(80, 7),
(80, 8);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `labels`
--

CREATE TABLE `labels` (
  `id` int(11) NOT NULL,
  `label_code` text NOT NULL,
  `page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `labels_custom`
--

CREATE TABLE `labels_custom` (
  `id` int(11) NOT NULL,
  `label_id` int(11) NOT NULL,
  `custom_label` text NOT NULL,
  `company_id` int(11) NOT NULL,
  `lang` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `labels_custom`
--

INSERT INTO `labels_custom` (`id`, `label_id`, `custom_label`, `company_id`, `lang`) VALUES
(28, 1, 'Custom Employee Name2', 5, 'en'),
(29, 3, 'Employee Custom First Name', 5, 'en'),
(30, 4, 'Custom Employee Title', 5, 'en'),
(31, 20, 'Mission custom Home Company', 5, 'en'),
(32, 93, 'tax stat 2 custom', 5, 'en'),
(359, 1, 'Nom', 4, 'fr'),
(360, 3, 'Prénom', 4, 'fr'),
(361, 4, 'Civilté', 4, 'fr'),
(362, 5, 'Marticule', 4, 'fr'),
(363, 6, 'VIP', 4, 'fr'),
(364, 7, 'Téléphone bureau', 4, 'fr'),
(365, 8, 'Téléphone portable', 4, 'fr'),
(366, 9, 'E-mail bureau', 4, 'fr'),
(367, 10, 'Commentaires', 4, 'fr'),
(368, 11, 'Utilisateurs', 4, 'fr'),
(369, 12, 'Nom', 4, 'fr'),
(370, 13, 'Prénom', 4, 'fr'),
(371, 14, 'Relation', 4, 'fr'),
(372, 15, 'Date de Naissance', 4, 'fr'),
(373, 16, 'A charge fiscale', 4, 'fr'),
(374, 17, 'Accompagne l´expatrié', 4, 'fr'),
(375, 18, 'Pays d´origine', 4, 'fr'),
(376, 19, 'Ville d´origine', 4, 'fr'),
(377, 20, 'Société d´origine', 4, 'fr'),
(378, 21, 'Adresse Société d´origine', 4, 'fr'),
(379, 22, 'Fonction Pays d´origine', 4, 'fr'),
(380, 23, 'Supérieur hiérarchique Pays d´origine', 4, 'fr'),
(381, 24, 'Téléphone', 4, 'fr'),
(382, 25, 'Adresse email', 4, 'fr'),
(383, 26, 'Composition Familiale', 4, 'fr'),
(384, 27, 'Nom', 4, 'fr'),
(385, 28, 'Lien de parenté', 4, 'fr'),
(386, 29, 'Numéro de téléphone', 4, 'fr'),
(387, 30, 'Adresse email', 4, 'fr'),
(388, 31, 'Module Google Map', 4, 'fr'),
(389, 32, 'Commentaires', 4, 'fr'),
(390, 33, 'Pays d´accueil', 4, 'fr'),
(391, 34, 'Pays d´accueil', 4, 'fr'),
(392, 35, 'Société d´accueil', 4, 'fr'),
(393, 36, 'Adresse Société d´accueil', 4, 'fr'),
(394, 37, 'Fonction Pays d´accueil', 4, 'fr'),
(395, 38, 'Supérieur hiérarchique Pays d´accueil', 4, 'fr'),
(396, 39, 'Téléphone', 4, 'fr'),
(397, 40, 'Adresse email', 4, 'fr'),
(398, 41, 'Composition familiale', 4, 'fr'),
(399, 42, 'Nom', 4, 'fr'),
(400, 43, 'Lien de parenté', 4, 'fr'),
(401, 44, 'Numéro de téléphone', 4, 'fr'),
(402, 45, 'Adresse email', 4, 'fr'),
(403, 46, 'Module Google Map', 4, 'fr'),
(404, 47, 'Commentaires', 4, 'fr'),
(405, 33, 'Pays d´accueil', 4, 'fr'),
(406, 34, 'Pays d´accueil', 4, 'fr'),
(407, 35, 'Société d´accueil', 4, 'fr'),
(408, 36, 'Adresse Société d´accueil', 4, 'fr'),
(409, 37, 'Fonction Pays d´accueil', 4, 'fr'),
(410, 38, 'Supérieur hiérarchique Pays d´accueil', 4, 'fr'),
(411, 39, 'Téléphone', 4, 'fr'),
(412, 40, 'Adresse email', 4, 'fr'),
(413, 41, 'Composition familiale', 4, 'fr'),
(414, 42, 'Nom', 4, 'fr'),
(415, 43, 'Lien de parenté', 4, 'fr'),
(416, 44, 'Numéro de téléphone', 4, 'fr'),
(417, 45, 'Adresse email', 4, 'fr'),
(418, 46, 'Module Google Map', 4, 'fr'),
(419, 47, 'Commentaires', 4, 'fr'),
(420, 48, 'Début de mission', 4, 'fr'),
(421, 49, 'Fin prévisionnelle de la mission', 4, 'fr'),
(422, 50, 'Date réelle fin de mission', 4, 'fr'),
(423, 51, 'Statut - Politique MI', 4, 'fr'),
(424, 52, 'Gestionnaire en charge du dossier', 4, 'fr'),
(425, 53, 'RH de référence', 4, 'fr'),
(426, 54, 'Commentaires', 4, 'fr'),
(427, 55, 'Package', 4, 'fr'),
(428, 56, 'Contrat', 4, 'fr'),
(429, 57, 'Affiliation', 4, 'fr'),
(430, 58, 'Immigration', 4, 'fr'),
(431, 59, 'Déménagement', 4, 'fr'),
(432, 60, 'Relocation', 4, 'fr'),
(433, 61, 'Affiliation', 4, 'fr'),
(434, 62, 'Immigration', 4, 'fr'),
(435, 63, 'Déménagement', 4, 'fr'),
(436, 64, 'Relocation', 4, 'fr'),
(437, 65, 'Statut Sécurité Sociale', 4, 'fr'),
(438, 66, 'Date de début de validité', 4, 'fr'),
(439, 67, 'Date de fin de validité', 4, 'fr'),
(440, 68, 'Pays d´origine', 4, 'fr'),
(441, 69, 'Prestataire', 4, 'fr'),
(442, 70, 'Coordonnées', 4, 'fr'),
(443, 71, 'Type d´assistance', 4, 'fr'),
(444, 72, 'Type d´assistance', 4, 'fr'),
(445, 73, 'Date d´envoi E-mail notification départ', 4, 'fr'),
(446, 74, 'Statut fiscal', 4, 'fr'),
(447, 75, 'Commentaires', 4, 'fr'),
(448, 76, 'Début affiliation', 4, 'fr'),
(449, 77, 'Fin affiliation', 4, 'fr'),
(450, 88, 'Pays d´accueil', 4, 'fr'),
(451, 89, 'Prestataire', 4, 'fr'),
(452, 90, 'Coordonnées', 4, 'fr'),
(453, 91, 'Type d´assistance', 4, 'fr'),
(454, 92, 'Date d´envoi E-mail notification départ', 4, 'fr'),
(455, 93, 'Statut fiscal', 4, 'fr'),
(456, 78, 'Société mandatée', 4, 'fr'),
(457, 79, 'Adresse email contact', 4, 'fr'),
(458, 80, 'Garde meuble', 4, 'fr'),
(459, 81, 'Date de début de validité', 4, 'fr'),
(460, 82, 'Date de fin de validité', 4, 'fr'),
(461, 83, 'Date de début de validité', 4, 'fr'),
(462, 84, 'Date de fin de validité', 4, 'fr'),
(463, 85, 'Société mandatée', 4, 'fr'),
(464, 86, 'Adresse email contact', 4, 'fr'),
(465, 87, 'Commentaires', 4, 'fr');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `languages`
--

CREATE TABLE `languages` (
  `id` tinyint(1) UNSIGNED NOT NULL,
  `language_name` varchar(100) NOT NULL,
  `language_directory` varchar(100) NOT NULL,
  `slug` varchar(10) NOT NULL,
  `language_code` char(2) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_directory`, `slug`, `language_code`, `default`) VALUES
(1, 'English', 'english', 'en', 'en', 0),
(2, 'français', 'french', 'fr', 'fr', 0),
(3, 'magyar', 'hungarian', 'hu', 'hu', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `normal_attributes_value`
--

CREATE TABLE `normal_attributes_value` (
  `id` int(11) NOT NULL,
  `lang_code` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` text,
  `definition` text,
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `definition`, `active`) VALUES
(1, 'edit_users', 'can add, edit, delete a user', 1),
(2, 'view_users', 'can view a user', 1),
(3, 'list_users', 'can view the users list page', 1),
(4, 'create_users', 'can create a user', 1),
(8, 'edit_companies', 'can add, edit, delete a company', 1),
(9, 'view_companies', 'can view a company', 1),
(10, 'list_companies', 'can view the companies list page', 1),
(36, 'edit_user', 'can add, edit, delete the user', 1),
(37, 'view_user', 'can view the user', 1),
(39, 'list_user', 'can view the user list page', 1),
(44, 'edit_dash', 'can add, edit, delete the dash', 1),
(45, 'view_dash', 'can view the dash', 1),
(46, 'list_group', 'can view the lists list group', 1),
(47, 'edit_group', 'can add, edit, delete the group', 1),
(48, 'view_group', 'can view the group', 1),
(55, 'list_dash', 'can see the dash menu button', 1),
(67, 'edit_self', 'able to edit own data', 1),
(70, 'admin', 'admin permission for group member tabulate', 1),
(71, 'view_languages', 'You can see the languages', 1),
(72, 'edit_languages', 'You can edit  the languages', 1),
(73, 'list_languages', 'You can list languages', 1),
(74, 'list_structures', NULL, 1),
(75, 'edit_structures', NULL, 1),
(76, 'view_structure', NULL, 1),
(77, 'list_cases', NULL, 1),
(78, 'edit_cases', NULL, 1),
(79, 'view_cases', NULL, 1),
(80, 'create_cases', NULL, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `status` tinyint(1) UNSIGNED DEFAULT NULL,
  `bank_id` smallint(5) UNSIGNED NOT NULL,
  `product_category` char(2) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `term` int(11) UNSIGNED DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `account_creation_fee` int(11) UNSIGNED DEFAULT NULL,
  `account_creation_fee_discount` varchar(255) DEFAULT NULL,
  `monthly payment` int(11) UNSIGNED DEFAULT NULL,
  `account_fee` varchar(255) DEFAULT NULL,
  `contract_amount` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `stat_dates`
--

CREATE TABLE `stat_dates` (
  `id` int(11) NOT NULL,
  `month` text NOT NULL,
  `month_date` text NOT NULL,
  `lang_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `stat_dates`
--

INSERT INTO `stat_dates` (`id`, `month`, `month_date`, `lang_id`) VALUES
(1, 'January', '01', 5),
(2, 'February', '02', 5),
(3, 'March', '03', 5),
(4, 'April', '04', 5),
(5, 'May', '05', 5),
(6, 'June', '06', 5),
(7, 'July', '07', 5),
(8, 'August', '08', 5),
(9, 'September', '09', 5),
(10, 'October', '10', 5),
(11, 'November', '11', 5),
(12, 'December', '12', 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `structures`
--

CREATE TABLE `structures` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_hungarian_ci NOT NULL,
  `product_categories` varchar(255) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `structures`
--

INSERT INTO `structures` (`id`, `title`, `product_categories`) VALUES
(1, 'LTP 1', 'HS,ML'),
(2, 'Mixed 1', 'HS,PL');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `uploaded_files`
--

CREATE TABLE `uploaded_files` (
  `id` int(11) NOT NULL,
  `created` date NOT NULL,
  `name` text NOT NULL,
  `employee_id` int(11) NOT NULL,
  `mission_id` int(11) NOT NULL,
  `deleted` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `user_picture` text,
  `default_lang` text NOT NULL,
  `level` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'I',
  `legal_relation` char(1) DEFAULT NULL,
  `mothers_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_hungarian_ci DEFAULT NULL,
  `id_card_no` varchar(8) DEFAULT NULL,
  `address_card_no` varchar(8) DEFAULT NULL,
  `company_reg_no` varchar(12) DEFAULT NULL,
  `tax_no` varchar(13) DEFAULT NULL,
  `education` char(1) DEFAULT NULL,
  `education_date` date DEFAULT NULL,
  `mnb_no` varchar(15) DEFAULT NULL,
  `comment` text CHARACTER SET utf8 COLLATE utf8_hungarian_ci,
  `product_categories` varchar(50) DEFAULT NULL,
  `structure_id` smallint(5) UNSIGNED DEFAULT NULL,
  `superior_id` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `user_picture`, `default_lang`, `level`, `status`, `legal_relation`, `mothers_name`, `id_card_no`, `address_card_no`, `company_reg_no`, `tax_no`, `education`, `education_date`, `mnb_no`, `comment`, `product_categories`, `structure_id`, `superior_id`) VALUES
(1, '127.0.0.1', 'admin@bank360.hu', '$2y$08$0rhD8Hqhlk3xX5xRphDtzejAZmJnoVuluQF69Di7G4MucOv.zcat6', '', 'admin@admin.com', '', NULL, NULL, 'gUald0tMYXsAQyWAiy97/O', 1268889823, 1505374087, 1, 'Admin', 'Bank360', 1, NULL, 'f5d9d3eeb4940d25bd2ce756d765d644.jpg', 'hu', 6, 'A', 'O', 'Anyja Neve', '.', '.', '.', '.', 'S', '2011-01-02', '.', '', 'ML', 1, 0),
(69, '2.14.28.172', 'struktura.vezeto@bank360.hu', '$2y$08$WOpSrR0WqQEvKZlHttqMd.kf6laJk73xWvrpKPWenGTeX4YmbSKDa', NULL, 'struktura.vezeto@bank360.hu', NULL, NULL, NULL, NULL, 1452583675, 1455632684, 1, 'Vezető', 'Struktúra', 1, NULL, '', 'hu', 6, 'A', 'O', 'Anyja Neve', 'Szem1111', 'LAKCIM2', 'VALLALK', 'ADOSZAM', 'S', '2011-01-02', 'MNBSZAM', '', 'ML', 1, 0),
(102, '82.224.232.59', 'kenez.balazs@bank360.hu', '$2y$08$YDzVJ1sic0Waw1pSUMoDP.dndUDN9kT/UJfHeIQ5Nij4HpEwyur1y', NULL, 'kenez.balazs@bank360.hu', NULL, NULL, NULL, 'cGlrLSpqMgyJqBh2wJ8GYO', 1453720112, 1505367083, 1, 'Balázs', 'Kenéz', 4, NULL, 'ea32037e8da00a8fe82433d14a3ef68d.jpg', 'hu', 5, 'A', 'E', 'Anyja Neve', 'Szem1111', 'LAKCIM2', 'VALLALK', 'ADOSZAM', 'S', '2014-01-23', 'MNBSZAM', '', 'HS', 1, 69),
(103, '82.224.232.59', 'al.partner@bank360.hu', '$2y$08$7HNvmGcxWyM.1.vzwpsxIeSwLg5jUJCd0.xQaTFjNX.2OalFbuWBy', NULL, 'al.partner@bank360.hu', NULL, NULL, NULL, 'RLk4eO1.cCo3wRJjcuoKUe', 1453896189, 1455631254, 1, 'Partner', 'Al', 4, NULL, '', 'hu', 3, 'A', 'E', 'Anyja Neve', 'Szem11', 'LAKCIM2', 'VALLALK', 'ADOSZAM', 'M', '2011-01-28', 'MNBSZAM', '', 'HS', 1, 102),
(114, '145.236.13.154', 'joinpaintball@bank360.hu', '$2y$08$t7RjlU5pj.P4pkdfzUcMCO8T8.76ZOOxQjkqkG6RtrPXWz6adIvei', NULL, 'joinpaintball@gmail.com', NULL, NULL, NULL, NULL, 1459429607, 1461058480, 0, 'Istvan', 'Kaholics', 1, '', '', 'hu', 0, '', '', '', '', '', NULL, '', '0', '2011-01-02', NULL, NULL, '', 1, 69);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_contact_info`
--

CREATE TABLE `users_contact_info` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `iranyitoszam` int(11) DEFAULT NULL,
  `varos` varchar(255) DEFAULT NULL,
  `utca_hazszam` varchar(255) DEFAULT NULL,
  `levelezesi_cim_is` tinyint(1) UNSIGNED DEFAULT NULL,
  `levelezes_iranyitoszam` int(11) DEFAULT NULL,
  `levelezes_varos` varchar(255) DEFAULT NULL,
  `levelezes_utca_hazszam` varchar(255) DEFAULT NULL,
  `mobiltelefonszam` varchar(20) DEFAULT NULL,
  `email_privat` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_contact_info`
--

INSERT INTO `users_contact_info` (`id`, `user_id`, `iranyitoszam`, `varos`, `utca_hazszam`, `levelezesi_cim_is`, `levelezes_iranyitoszam`, `levelezes_varos`, `levelezes_utca_hazszam`, `mobiltelefonszam`, `email_privat`) VALUES
(5, 140, NULL, '', '', NULL, NULL, '', '', '', ''),
(6, 141, NULL, '', '', NULL, NULL, '', '', '', ''),
(8, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(9, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(10, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(11, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(12, 102, 2222, 'Békés', 'Utca u. 15.', 1, NULL, NULL, NULL, '', 'set@erhazukdfh.er'),
(13, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(14, 102, 2222, 'Békés', 'Utca u. 15.', 1, NULL, NULL, NULL, '', 'set@erhazukdfh.er'),
(15, 103, 2222, 'Békés', 'Alma u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@hadfh.er'),
(16, 69, 2222, 'Budapest', 'Utca u. 15.', 1, NULL, NULL, NULL, '+3615452544', 'set@erhsgjkb.er'),
(17, 1, 1061, 'Budapest', 'Andrássy út 10.', 1, NULL, NULL, NULL, '+3612345678', 'info@bank360.hu');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(404, 1, 1),
(403, 69, 8),
(401, 102, 8),
(402, 103, 8),
(360, 114, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users_sales_codes`
--

CREATE TABLE `users_sales_codes` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `bank_id` smallint(5) UNSIGNED NOT NULL,
  `kapcsolattarto_fiok_neve` varchar(255) DEFAULT NULL,
  `kapcsolattarto_fiok_kodja` varchar(255) DEFAULT NULL,
  `kapcsolattarto_fiok_cime` varchar(255) DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `azonosito` varchar(255) DEFAULT NULL,
  `product_categories` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `users_sales_codes`
--

INSERT INTO `users_sales_codes` (`id`, `user_id`, `bank_id`, `kapcsolattarto_fiok_neve`, `kapcsolattarto_fiok_kodja`, `kapcsolattarto_fiok_cime`, `datum`, `azonosito`, `product_categories`) VALUES
(2, 103, 9, 'Kakukk Fiók Név', 'Fiók kód', 'Lombcsúcs 14.', '2016-09-21', '84/2', 'HS');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `usertracking`
--

CREATE TABLE `usertracking` (
  `id` int(11) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `user_identifier` varchar(255) NOT NULL,
  `request_uri` text NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  `client_ip` varchar(50) NOT NULL,
  `client_user_agent` text NOT NULL,
  `referer_page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `attributes`
--
ALTER TABLE `attributes`
  ADD UNIQUE KEY `attribute_id` (`attribute_id`,`entity_id`),
  ADD KEY `attribute_id_2` (`attribute_id`);

--
-- A tábla indexei `attributes_default_labels`
--
ALTER TABLE `attributes_default_labels`
  ADD PRIMARY KEY (`attribute_id`);

--
-- A tábla indexei `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `cases_beneficiary`
--
ALTER TABLE `cases_beneficiary`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `cases_client_data`
--
ALTER TABLE `cases_client_data`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `cases_common`
--
ALTER TABLE `cases_common`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- A tábla indexei `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- A tábla indexei `custom_labels`
--
ALTER TABLE `custom_labels`
  ADD KEY `id` (`id`);

--
-- A tábla indexei `dynamic_attributes`
--
ALTER TABLE `dynamic_attributes`
  ADD PRIMARY KEY (`attribute_id`);

--
-- A tábla indexei `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `groups_permission`
--
ALTER TABLE `groups_permission`
  ADD KEY `perm_id_group_id_index` (`perm_id`,`group_id`);

--
-- A tábla indexei `labels`
--
ALTER TABLE `labels`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `labels_custom`
--
ALTER TABLE `labels_custom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- A tábla indexei `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_index` (`id`);

--
-- A tábla indexei `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- A tábla indexei `stat_dates`
--
ALTER TABLE `stat_dates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- A tábla indexei `structures`
--
ALTER TABLE `structures`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `uploaded_files`
--
ALTER TABLE `uploaded_files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users_contact_info`
--
ALTER TABLE `users_contact_info`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- A tábla indexei `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- A tábla indexei `usertracking`
--
ALTER TABLE `usertracking`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `banks`
--
ALTER TABLE `banks`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT a táblához `cases_beneficiary`
--
ALTER TABLE `cases_beneficiary`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT a táblához `cases_client_data`
--
ALTER TABLE `cases_client_data`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT a táblához `cases_common`
--
ALTER TABLE `cases_common`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT a táblához `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT a táblához `custom_labels`
--
ALTER TABLE `custom_labels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT a táblához `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT a táblához `labels`
--
ALTER TABLE `labels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `labels_custom`
--
ALTER TABLE `labels_custom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=466;
--
-- AUTO_INCREMENT a táblához `languages`
--
ALTER TABLE `languages`
  MODIFY `id` tinyint(1) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT a táblához `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT a táblához `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `stat_dates`
--
ALTER TABLE `stat_dates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT a táblához `structures`
--
ALTER TABLE `structures`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT a táblához `uploaded_files`
--
ALTER TABLE `uploaded_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;
--
-- AUTO_INCREMENT a táblához `users_contact_info`
--
ALTER TABLE `users_contact_info`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT a táblához `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=405;
--
-- AUTO_INCREMENT a táblához `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT a táblához `usertracking`
--
ALTER TABLE `usertracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD CONSTRAINT `login_attempts_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Megkötések a táblához `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`id`);

--
-- Megkötések a táblához `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Megkötések a táblához `users_sales_codes`
--
ALTER TABLE `users_sales_codes`
  ADD CONSTRAINT `users_sales_codes_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `banks` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
